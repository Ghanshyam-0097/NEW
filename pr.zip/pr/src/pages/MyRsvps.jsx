import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import api from "@/api/axios";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const fmt = (v) => {
  const d = new Date(v);
  return isNaN(d.getTime()) ? "TBA" : d.toLocaleString();
};

export default function MyRsvps() {
  const navigate = useNavigate();

  const {
    data: rsvps = [],
    isLoading,
    isError,
    error,
  } = useQuery({
    queryKey: ["my-rsvps"],
    queryFn: async () => {
      const res = await api.get("/rsvps/mine");
      return Array.isArray(res.data) ? res.data : [];
    },
    retry: 1,
  });

  if (isLoading) return <p className="p-4">Loading RSVPs…</p>;
  if (isError)
    return (
      <p className="p-4 text-red-600">
        Failed to load RSVPs: {String(error?.message || "unknown error")}
      </p>
    );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">My RSVPs</h1>
        <p className="text-muted-foreground">
          Events you’ve responded to and their details
        </p>
      </div>

      {!rsvps.length ? (
        <Card>
          <CardHeader>
            <CardTitle>No RSVPs yet</CardTitle>
            <CardDescription>
              You haven’t RSVP’d to any events. Check out upcoming ones.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate("/events")}>Browse Events</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {rsvps.map((r) => (
            <Card key={r.id || `${r.eventId}-${r.userId}`}>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>{r.eventTitle || "Event"}</CardTitle>
                  <CardDescription>
                    {fmt(r.eventDate)}
                    {r.location ? ` • ${r.location}` : ""}
                  </CardDescription>
                </div>
                {r.eventId && (
                  <Button
                    variant="outline"
                    onClick={() => navigate(`/events/${r.eventId}`)}
                  >
                    View Event
                  </Button>
                )}
              </CardHeader>
              {r.notes && (
                <CardContent>
                  <p className="text-sm text-muted-foreground">{r.notes}</p>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
