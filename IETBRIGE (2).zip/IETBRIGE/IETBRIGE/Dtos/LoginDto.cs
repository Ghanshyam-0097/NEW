﻿using System.ComponentModel.DataAnnotations;

namespace IETBRIGE.Dtos
{
    public class LoginDto
    {
        [EmailAddress, Required]
        public string Email { get; set; } = null!;

        [MinLength(6), Required]
        public string Password { get; set; } = null!;
    }
}
