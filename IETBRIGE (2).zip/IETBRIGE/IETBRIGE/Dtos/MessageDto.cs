﻿namespace IETBRIGE.Dtos
{
    public class MessageDto
    {
        public int? Id { get; set; }
        public int ReceiverId { get; set; }
        public string Content { get; set; } = null!;
    }
}
