﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using IETBRIGE.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [Authorize(Roles = "Admin, Alumni")]
    [ApiController]
    [Route("api/announcements")]
    public class AnnouncementsController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;

        public AnnouncementsController(AlumniManagementDbContext context)
        {
            _context = context;
        }

        /* -------- READ: all -------- */
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var announcements = await _context.Announcements
                .OrderByDescending(a => a.CreatedAt)
                .ToListAsync();

            return Ok(announcements);
        }

        /* -------- READ: single -------- */
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var a = await _context.Announcements.FindAsync(id);
            if (a == null) return NotFound("Announcement not found.");
            return Ok(a);
        }

        /* -------- CREATE (Admin) -------- */
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([FromBody] AnnouncementDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.Title) || string.IsNullOrWhiteSpace(dto.Message))
                return BadRequest("Title and Message are required.");

            var adminId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var announcement = new Announcement
            {
                Title = dto.Title.Trim(),
                Message = dto.Message.Trim(),
                CreatedBy = adminId,
                CreatedAt = DateTime.UtcNow
            };

            _context.Announcements.Add(announcement);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = announcement.Id }, announcement);
        }

        /* -------- UPDATE (Admin) -------- */
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Update(int id, [FromBody] AnnouncementDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.Title) || string.IsNullOrWhiteSpace(dto.Message))
                return BadRequest("Title and Message are required.");

            var a = await _context.Announcements.FindAsync(id);
            if (a == null) return NotFound("Announcement not found.");

            a.Title = dto.Title.Trim();
            a.Message = dto.Message.Trim();

            await _context.SaveChangesAsync();
            return Ok(a);
        }

        /* -------- DELETE (Admin) -------- */
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var a = await _context.Announcements.FindAsync(id);
            if (a == null) return NotFound("Announcement not found.");

            _context.Announcements.Remove(a);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
