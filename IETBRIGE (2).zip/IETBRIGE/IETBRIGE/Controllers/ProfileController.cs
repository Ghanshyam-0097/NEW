﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [Authorize(Roles = "Alumni")]
    [ApiController]
    [Route("api/profile")]
    public class ProfileController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;

        public ProfileController(AlumniManagementDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetProfile()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return NotFound();

            return Ok(new
            {
                user.FullName,
                user.Email,
                user.Phone,
                user.ProfilePic,
                user.Bio,
                user.BatchYear
            });
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProfile(UpdateProfileDto dto)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return NotFound();

            user.FullName = dto.FullName;
            user.Phone = dto.Phone;
            user.ProfilePic = dto.ProfilePic;
            user.Bio = dto.Bio;
            user.BatchYear = dto.BatchYear;

            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
