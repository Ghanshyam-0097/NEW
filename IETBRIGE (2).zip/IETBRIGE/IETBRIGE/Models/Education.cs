﻿using System;
using System.Collections.Generic;

namespace IETBRIGE.Models
{
    public class Education
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string? Degree { get; set; }
        public string? Branch { get; set; }
        public string? Institute { get; set; }
        public int? GraduationYear { get; set; }

        public User User { get; set; } = null!;
    }
}
