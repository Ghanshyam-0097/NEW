﻿namespace IETBRIGE.Dtos
{
    public class UpdateProfileDto
    {
        public string FullName { get; set; } = null!;
        public string? Phone { get; set; }
        public string? ProfilePic { get; set; }
        public string? Bio { get; set; }
        public int? BatchYear { get; set; }
    }
}
