﻿using System.Linq;
using IETBRIGE.Models;
using BCrypt.Net;
using IETBRIGE.Data;

namespace IETBRIGE.Data
{
    public static class SeedData
    {
        public static void SeedAdmin(AlumniManagementDbContext context)
        {
            if (!context.Users.Any(u => u.Role == "Admin"))
            {
                var admin = new User
                {
                    FullName = "Super Admin",
                    Email = "admin@alumni.com",
                    Role = "Admin",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin@12345"),
                    CreatedAt = DateTime.UtcNow
                };
                context.Users.Add(admin);
                context.SaveChanges();
            }
        }
    }
}

