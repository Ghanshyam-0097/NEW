﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using IETBRIGE.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [ApiController]
    [Route("api/rsvps")]
    [Authorize] // require auth; roles are set per-action below
    public class RSVPsController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;

        public RSVPsController(AlumniManagementDbContext context)
        {
            _context = context;
        }

        /* -------- Alumni: create RSVP -------- */
        [HttpPost]
        [Authorize(Roles = "Alumni")]
        public async Task<IActionResult> RSVP([FromBody] RSVPDto dto)
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized("Invalid or missing user id claim.");
            if (dto == null || dto.EventId <= 0) return BadRequest("Invalid request.");

            // Ensure event exists
            var eventExists = await _context.Events.AnyAsync(e => e.Id == dto.EventId);
            if (!eventExists) return BadRequest("Event not found.");

            var already = await _context.RSVPs.AnyAsync(r => r.EventId == dto.EventId && r.UserId == userId);
            if (already) return BadRequest("Already RSVPed to this event.");

            _context.RSVPs.Add(new RSVP
            {
                EventId = dto.EventId,
                UserId = userId.Value,
                RSVPDate = DateTime.UtcNow
            });

            await _context.SaveChangesAsync();
            return Ok("RSVP successful");
        }

        /* -------- Alumni: my RSVPs -------- */
        [HttpGet("mine")]
        [Authorize(Roles = "Alumni")]
        public async Task<IActionResult> MyRSVPs()
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized("Invalid or missing user id claim.");

            // Project to flat DTO to avoid JSON reference cycles
            var rsvps = await _context.RSVPs
                .Where(r => r.UserId == userId)
                .Select(r => new
                {
                    r.Id,
                    r.EventId,
                    r.RSVPDate,
                    Event = new
                    {
                        r.Event.Id,
                        r.Event.Title,
                        r.Event.EventDate,
                        r.Event.Location
                    }
                })
                .ToListAsync();

            return Ok(rsvps);
        }

        /* -------- Admin: RSVPs by event -------- */
        [HttpGet("by-event/{eventId:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetByEvent(int eventId)
        {
            var exists = await _context.Events.AnyAsync(e => e.Id == eventId);
            if (!exists) return NotFound("Event not found");

            var list = await _context.RSVPs
                .Where(r => r.EventId == eventId)
                .Join(_context.Users,
                      r => r.UserId,
                      u => u.Id,
                      (r, u) => new
                      {
                          r.Id,
                          r.EventId,
                          r.UserId,
                          FullName = u.FullName,
                          Email = u.Email,
                          r.RSVPDate
                      })
                .OrderByDescending(x => x.RSVPDate)
                .ToListAsync();

            return Ok(list);
        }

        private int? GetUserId()
        {
            var v = User.FindFirstValue(ClaimTypes.NameIdentifier)
                 ?? User.FindFirst("sub")?.Value
                 ?? User.FindFirst("nameid")?.Value;
            return int.TryParse(v, out var id) ? id : null;
        }
    }
}

