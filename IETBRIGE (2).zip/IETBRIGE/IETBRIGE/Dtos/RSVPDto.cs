﻿namespace IETBRIGE.Dtos
{
    public class RSVPDto
    {
        public int EventId { get; set; }
    }
}
