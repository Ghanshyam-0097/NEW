﻿using System.ComponentModel.DataAnnotations;

namespace IETBRIGE.Dtos
{
    public class EducationDto
    {
        public int? Id { get; set; }  // Optional for creation, no Required needed

        [Required(ErrorMessage = "Degree is required.")]
        public string Degree { get; set; } = null!;  // Non-nullable due to Required

        [Required(ErrorMessage = "Branch is required.")]
        public string Branch { get; set; } = null!;

        [Required(ErrorMessage = "Institute is required.")]
        public string Institute { get; set; } = null!;

        [Required(ErrorMessage = "Graduation Year is required.")]
        [Range(1900, 2100, ErrorMessage = "Graduation Year must be between 1900 and 2100.")]
        public int GraduationYear { get; set; }
    }
}
