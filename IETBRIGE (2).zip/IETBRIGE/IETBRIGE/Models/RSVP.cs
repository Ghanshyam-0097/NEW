﻿using System;
using System.Collections.Generic;

namespace IETBRIGE.Models
{
    public class RSVP
    {
        public int Id { get; set; }
        public int EventId { get; set; }
        public int UserId { get; set; }
        public DateTime RSVPDate { get; set; }

        public Event Event { get; set; } = null!;
        public User User { get; set; } = null!;
    }
}
