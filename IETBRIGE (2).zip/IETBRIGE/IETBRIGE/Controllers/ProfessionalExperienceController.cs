﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using IETBRIGE.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [Authorize(Roles = "Alumni")]
    [ApiController]
    [Route("api/professional-experience")]
    public class ProfessionalExperienceController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;

        public ProfessionalExperienceController(AlumniManagementDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var experiences = await _context.ProfessionalExperiences
                .Where(pe => pe.UserId == userId)
                .ToListAsync();
            return Ok(experiences);
        }

        [HttpPost]
        public async Task<IActionResult> Create(ProfessionalExperienceDto dto)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var experience = new ProfessionalExperience
            {
                UserId = userId,
                Company = dto.Company,
                Title = dto.Title,
                Industry = dto.Industry,
                StartDate = dto.StartDate,
                EndDate = dto.EndDate
            };
            _context.ProfessionalExperiences.Add(experience);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetAll), new { id = experience.Id }, experience);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, ProfessionalExperienceDto dto)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var experience = await _context.ProfessionalExperiences
                .FirstOrDefaultAsync(pe => pe.Id == id && pe.UserId == userId);
            if (experience == null) return NotFound();

            experience.Company = dto.Company;
            experience.Title = dto.Title;
            experience.Industry = dto.Industry;
            experience.StartDate = dto.StartDate;
            experience.EndDate = dto.EndDate;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var experience = await _context.ProfessionalExperiences
                .FirstOrDefaultAsync(pe => pe.Id == id && pe.UserId == userId);
            if (experience == null) return NotFound();

            _context.ProfessionalExperiences.Remove(experience);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}

