﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using IETBRIGE.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [Authorize(Roles = "Alumni")]
    [ApiController]
    [Route("api/education")]
    public class EducationController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;

        public EducationController(AlumniManagementDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var educations = await _context.Educations.Where(e => e.UserId == userId).ToListAsync();
            return Ok(educations);
        }

        [HttpPost]
        public async Task<IActionResult> Create(EducationDto dto)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var education = new Education
            {
                UserId = userId,
                Degree = dto.Degree,
                Branch = dto.Branch,
                Institute = dto.Institute,
                GraduationYear = dto.GraduationYear
            };
            _context.Educations.Add(education);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetAll), new { id = education.Id }, education);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, EducationDto dto)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var education = await _context.Educations.FirstOrDefaultAsync(e => e.Id == id && e.UserId == userId);
            if (education == null) return NotFound();

            education.Degree = dto.Degree;
            education.Branch = dto.Branch;
            education.Institute = dto.Institute;
            education.GraduationYear = dto.GraduationYear;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var education = await _context.Educations.FirstOrDefaultAsync(e => e.Id == id && e.UserId == userId);
            if (education == null) return NotFound();

            _context.Educations.Remove(education);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
