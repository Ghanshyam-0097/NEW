﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [ApiController]
    [Route("api/users")]
    [Authorize(Roles = "Admin,Alumni")] // both roles allowed
    public class UsersController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;
        public UsersController(AlumniManagementDbContext context) => _context = context;

        // --- Lightweight DTO for lists ---
        private sealed class UserListItemDto
        {
            public int Id { get; set; }
            public string? FullName { get; set; }
            public string? Email { get; set; }
            public string? Role { get; set; }
            public DateTime? CreatedAt { get; set; }
        }

        /// <summary>
        /// Get a list of message recipients (excludes current user).
        /// Query:
        ///  q     : search term (name/email, case-insensitive)
        ///  role  : "Alumni" (default for alumni), "Admin", or "All" (default for admins)
        ///  take  : page size (1..50, default 20)
        ///  skip  : offset (default 0)
        ///  sort  : "name_asc" (default), "name_desc", "recent", "oldest"
        /// </summary>
        [HttpGet("recipients")]
        public async Task<IActionResult> GetRecipients(
            [FromQuery] string? q,
            [FromQuery] string? role,
            [FromQuery] int take = 20,
            [FromQuery] int skip = 0,
            [FromQuery] string sort = "name_asc")
        {
            var me = GetUserId();
            if (me == null) return Unauthorized("Missing user id.");

            var isAdmin = User.IsInRole("Admin");

            // Resolve effective role: Admins default to All; Alumni default to Alumni.
            var effectiveRole = string.IsNullOrWhiteSpace(role)
                ? (isAdmin ? "All" : "Alumni")
                : role.Trim();

            // sanitize paging
            if (take < 1) take = 1;
            if (take > 50) take = 50;
            if (skip < 0) skip = 0;

            var query = _context.Users.AsNoTracking()
                .Where(u => u.Id != me); // exclude self

            // Alumni cannot elevate to "All"/"Admin" via query param
            if (!isAdmin)
            {
                effectiveRole = "Alumni";
            }

            // Role filter unless "All" (case-insensitive)
            if (!"All".Equals(effectiveRole, StringComparison.OrdinalIgnoreCase))
            {
                var roleLower = effectiveRole.ToLower();
                query = query.Where(u => (u.Role ?? "").ToLower() == roleLower);
            }

            // Case-insensitive search by name/email
            if (!string.IsNullOrWhiteSpace(q))
            {
                var ql = q.Trim().ToLower();
                query = query.Where(u =>
                    (u.FullName ?? "").ToLower().Contains(ql) ||
                    (u.Email ?? "").ToLower().Contains(ql));
            }

            // Sorting
            query = (sort ?? string.Empty).ToLower() switch
            {
                "name_desc" => query.OrderByDescending(u => u.FullName).ThenBy(u => u.Id),
                "recent" => query.OrderByDescending(u => u.CreatedAt).ThenBy(u => u.Id),
                "oldest" => query.OrderBy(u => u.CreatedAt).ThenBy(u => u.Id),
                _ => query.OrderBy(u => u.FullName).ThenBy(u => u.Id), // name_asc
            };

            var list = await query
                .Skip(skip)
                .Take(take)
                .Select(u => new RecipientDto
                {
                    Id = u.Id,
                    FullName = u.FullName,
                    Email = u.Email
                })
                .ToListAsync();

            return Ok(list);
        }

        /// <summary>
        /// General users list for dashboards.
        /// Example: /api/users?role=Alumni&take=5&sort=createdAt_desc&q=john
        /// Sort: createdAt_desc (default), createdAt_asc, name_asc, name_desc, recent, oldest
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetUsers(
            [FromQuery] string? q,
            [FromQuery] string? role,
            [FromQuery] int take = 20,
            [FromQuery] int skip = 0,
            [FromQuery] string sort = "createdAt_desc")
        {
            var me = GetUserId();
            if (me == null) return Unauthorized("Missing user id.");
            var isAdmin = User.IsInRole("Admin");

            // Admins default to All; Alumni default to Alumni (and cannot escalate)
            var effectiveRole = string.IsNullOrWhiteSpace(role)
                ? (isAdmin ? "All" : "Alumni")
                : role.Trim();

            if (!isAdmin) effectiveRole = "Alumni";

            if (take < 1) take = 1;
            if (take > 50) take = 50;
            if (skip < 0) skip = 0;

            var query = _context.Users.AsNoTracking();

            // Role filter unless "All" (case-insensitive)
            if (!"All".Equals(effectiveRole, StringComparison.OrdinalIgnoreCase))
            {
                var roleLower = effectiveRole.ToLower();
                query = query.Where(u => (u.Role ?? "").ToLower() == roleLower);
            }

            // Search
            if (!string.IsNullOrWhiteSpace(q))
            {
                var ql = q.Trim().ToLower();
                query = query.Where(u =>
                    (u.FullName ?? "").ToLower().Contains(ql) ||
                    (u.Email ?? "").ToLower().Contains(ql));
            }

            // Sorting
            var s = (sort ?? "").Replace("_", "").ToLower();
            query = s switch
            {
                "nameasc" => query.OrderBy(u => u.FullName).ThenBy(u => u.Id),
                "namedesc" => query.OrderByDescending(u => u.FullName).ThenBy(u => u.Id),
                "createdatasc" or "oldest"
                                   => query.OrderBy(u => u.CreatedAt).ThenBy(u => u.Id),
                "recent" or "createdatdesc" or ""
                                   => query.OrderByDescending(u => u.CreatedAt).ThenBy(u => u.Id),
                _ => query.OrderByDescending(u => u.CreatedAt).ThenBy(u => u.Id),
            };

            var list = await query
                .Skip(skip)
                .Take(take)
                .Select(u => new UserListItemDto
                {
                    Id = u.Id,
                    FullName = u.FullName,
                    Email = u.Email,
                    Role = u.Role,
                    CreatedAt = u.CreatedAt
                })
                .ToListAsync();

            return Ok(list);
        }

        /// <summary>
        /// Dedicated: recent alumni only.
        /// GET /api/users/recent-alumni?take=5
        /// </summary>
        [HttpGet("recent-alumni")]
        public async Task<IActionResult> GetRecentAlumni([FromQuery] int take = 5)
        {
            if (take < 1) take = 1;
            if (take > 50) take = 50;

            var list = await _context.Users.AsNoTracking()
                .Where(u => (u.Role ?? "").ToLower() == "alumni")
                .OrderByDescending(u => u.CreatedAt)
                .Take(take)
                .Select(u => new UserListItemDto
                {
                    Id = u.Id,
                    FullName = u.FullName,
                    Email = u.Email,
                    Role = u.Role,
                    CreatedAt = u.CreatedAt
                })
                .ToListAsync();

            return Ok(list);
        }

        private int? GetUserId()
        {
            var v = User.FindFirstValue(ClaimTypes.NameIdentifier)
                     ?? User.FindFirst("sub")?.Value
                     ?? User.FindFirst("nameid")?.Value;
            return int.TryParse(v, out var id) ? id : null;
        }
    }
}
