﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using IETBRIGE.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [ApiController]
    [Route("api/jobpostings")]
    public class JobPostingsController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;

        public JobPostingsController(AlumniManagementDbContext context)
        {
            _context = context;
        }

        /* -------- GET: /api/jobpostings -------- */
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var jobs = await _context.JobPostings
                .OrderByDescending(j => j.PostedAt)
                .ToListAsync();

            return Ok(jobs);
        }

        /* -------- GET: /api/jobpostings/{id} -------- */
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var job = await _context.JobPostings.FindAsync(id);
            if (job == null) return NotFound();
            return Ok(job);
        }

        /* -------- POST: /api/jobpostings  (Admin or Alumni) -------- */
        [HttpPost]
        [Authorize(Roles = "Admin,Alumni")]
        public async Task<IActionResult> Create([FromBody] JobPostingDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var userIdStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (!int.TryParse(userIdStr, out var userId))
                return Unauthorized("Invalid or missing user id claim.");

            var job = new JobPosting
            {
                UserId = userId,                 // creator (alumni or admin)
                Title = dto.Title,
                Company = dto.Company,
                Location = dto.Location,
                Description = dto.Description,
                PostedAt = DateTime.UtcNow
            };

            _context.JobPostings.Add(job);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = job.Id }, job);
        }

        /* -------- PUT: /api/jobpostings/{id}  (Admin only) -------- */
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Update(int id, [FromBody] JobPostingDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var job = await _context.JobPostings.FindAsync(id);
            if (job == null) return NotFound();

            job.Title = dto.Title;
            job.Company = dto.Company;
            job.Location = dto.Location;
            job.Description = dto.Description;
            // job.UpdatedAt = DateTime.UtcNow; // if you have this field

            await _context.SaveChangesAsync();
            return Ok(job); // or NoContent();
        }

        /* -------- DELETE: /api/jobpostings/{id}  (Admin only) -------- */
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var job = await _context.JobPostings.FindAsync(id);
            if (job == null) return NotFound();

            _context.JobPostings.Remove(job);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}

