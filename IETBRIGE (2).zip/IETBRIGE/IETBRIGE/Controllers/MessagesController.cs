﻿using System.Security.Claims;
using IETBRIGE.Data;
using IETBRIGE.Dtos;
using IETBRIGE.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IETBRIGE.Controllers
{
    [ApiController]
    [Route("api/messages")]
    [Authorize(Roles = "Admin,Alumni")] // <-- allow both
    public class MessagesController : ControllerBase
    {
        private readonly AlumniManagementDbContext _context;
        public MessagesController(AlumniManagementDbContext context) => _context = context;

        [HttpGet("inbox")]
        public async Task<IActionResult> Inbox()
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized("Invalid or missing user id claim.");

            var messages = await _context.Messages
                .Where(m => m.ReceiverId == userId)
                .OrderByDescending(m => m.SentAt)
                .Select(m => new
                {
                    id = m.Id,
                    senderId = m.SenderId,
                    senderName = m.Sender.FullName,
                    content = m.Content,
                    sentAt = m.SentAt,
                    isRead = m.IsRead
                })
                .ToListAsync();

            return Ok(messages);
        }

        [HttpGet("sent")]
        public async Task<IActionResult> Sent()
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized("Invalid or missing user id claim.");

            var messages = await _context.Messages
                .Where(m => m.SenderId == userId)
                .OrderByDescending(m => m.SentAt)
                .Select(m => new
                {
                    id = m.Id,
                    receiverId = m.ReceiverId,
                    receiverName = m.Receiver.FullName,
                    content = m.Content,
                    sentAt = m.SentAt,
                    isRead = m.IsRead
                })
                .ToListAsync();

            return Ok(messages);
        }

        [HttpPost]
        public async Task<IActionResult> Send([FromBody] MessageDto dto)
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized("Invalid or missing user id claim.");
            if (dto == null || dto.ReceiverId <= 0 || string.IsNullOrWhiteSpace(dto.Content))
                return BadRequest("Receiver and content are required.");

            // allow sending to anyone who exists (Admin or Alumni)
            var receiver = await _context.Users.FirstOrDefaultAsync(u => u.Id == dto.ReceiverId);
            if (receiver == null) return BadRequest("Receiver does not exist");
            if (receiver.Id == userId) return BadRequest("You cannot message yourself.");

            var message = new Message
            {
                SenderId = userId.Value,
                ReceiverId = dto.ReceiverId,
                Content = dto.Content.Trim(),
                SentAt = DateTime.UtcNow,
                IsRead = false
            };

            _context.Messages.Add(message);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                id = message.Id,
                receiverId = message.ReceiverId,
                receiverName = receiver.FullName,
                content = message.Content,
                sentAt = message.SentAt,
                isRead = message.IsRead
            });
        }

        [HttpPut("{id:int}/read")]
        public async Task<IActionResult> MarkAsRead(int id)
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized("Invalid or missing user id claim.");

            var message = await _context.Messages
                .SingleOrDefaultAsync(m => m.Id == id && m.ReceiverId == userId);

            if (message == null) return NotFound();

            message.IsRead = true;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized("Invalid or missing user id claim.");

            var message = await _context.Messages
                .SingleOrDefaultAsync(m => m.Id == id && (m.SenderId == userId || m.ReceiverId == userId));

            if (message == null) return NotFound();

            _context.Messages.Remove(message);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private int? GetUserId()
        {
            var v = User.FindFirstValue(ClaimTypes.NameIdentifier)
                     ?? User.FindFirst("sub")?.Value
                     ?? User.FindFirst("nameid")?.Value;
            return int.TryParse(v, out var id) ? id : null;
        }
    }
}

